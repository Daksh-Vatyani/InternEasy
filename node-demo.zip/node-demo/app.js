var express = require("express");
var path = require('path');
var app = express();
var port = 8080;
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname,'/')));
// app.use(express.static('public'));


var mongoose = require("mongoose");
mongoose.Promise = global.Promise;
mongoose.connect("mongodb://localhost:27017/node-demo");
var nameSchema = new mongoose.Schema({
    fullName: String,
    dob: String,
    email: String,
    city: String,
    password: String,
    cpassword: String
});
var User = mongoose.model("User", nameSchema);

var recSchema = new mongoose.Schema({
    fullName: String,
    dob: String,
    cname: String,
    email: String,
    city: String,
    password: String,
    cpassword: String
});
var User2 = mongoose.model("User2", recSchema);

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/reg.html");
});

app.post("/addrec", (req, res) => {
    var myData = new User2(req.body);
    myData.save()
        .then(item => {
            res.send("rec saved to database");
        })
        .catch(err => {
            res.status(400).send("Unable to save to database");
        });
});

app.post("/addname", (req, res) => {
    var myData = new User(req.body);
    myData.save()
        .then(item => {
            res.send("Name saved to database");
        })
        .catch(err => {
            res.status(400).send("Unable to save to database");
        });
});

app.listen(port, () => {
    console.log("Server listening on port " + port);
});

//----------------------------------------------



'use strict';

var getData = function(request, response) {
    return response.render("login.html");
}

var postData = function(request, response) {
    var DB = request.app.locals.node-demo;

    var userDetails = {
        email: request.body.email,
        password: request.body.password
    };

    DB.collection("user2").findOne(userDetails, function(error, recruiter) {
        if(error) {
            return resposnse.send("db error occurred");
        }

        if(!recruiter) {
            return response.redirect("/login.html");
        }

        // Set the session for the user.
        request.session.user = recruiter;

        response.redirect("/reg.html");
    });
}

var logout = function(request, response) {
    request.session.user = null;
    response.redirect("/login.html");
}

exports.getData = getData;
exports.postData = postData;
exports.logout = logout;